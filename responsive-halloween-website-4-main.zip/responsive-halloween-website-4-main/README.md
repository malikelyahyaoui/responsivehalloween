# Responsive Halloween Website
## [Watch it on youtube](https://youtu.be/4YePjH9j7UE)
### Responsive Halloween Website

- Responsive Halloween Website Design Using HTML CSS And JavaScript
- Contains a flickering effect that changes the image of the pumpkin.
- When you move the mouse over the image, it acquires a 3D effect.
- Developed first with the Mobile First methodology, then for desktop.
- Compatible with all mobile devices and with a beautiful and pleasant user interface.

💙 Join the channel to see more videos like this. [Bedimcode](https://www.youtube.com/@Bedimcode)

![preview img](/preview.png)
